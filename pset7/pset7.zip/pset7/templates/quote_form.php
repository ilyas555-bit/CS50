<form action="quote.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus name="symbol" placeholder="Symbol" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Check!</button>
        </div>
    </fieldset>
</form>

