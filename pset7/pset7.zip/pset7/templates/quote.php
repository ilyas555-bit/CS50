<?php
    
    // prints name, symbol and price of stock
    print("A share of " . $name . " (" . $symbol .  ") costs $" . number_format($price, 2) . "."); 
   
 ?>

