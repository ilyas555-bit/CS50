<form action="deposit.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus name="deposit" placeholder="Deposit (in dollars)" type="number"/>
        </div>
        <div class="form-group">
            <button type="deposit" class="btn btn-default">Deposit!</button>
        </div>
    </fieldset>
</form>

